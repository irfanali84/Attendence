from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
import os
import tkinter

def root():
    os.system("Student_details.py")

def train_data():
    os.system("train_photos.py")

def face_data():
    os.system("face_data.py")

def Attendance():
    os.system("attendance.py")

def open_img():
    os.startfile("data")

def devloper():
    os.system("devloper.py")

def help():
    os.system("help.py")

def iExit():
    self.iExit=tkinter.messagebox.askyesno("Face recognition", "Are you sure exit this project",parent=self)
    if self.iExit>0:
        self.destroy()
    else:
        return

self=Tk()
self.title("Face Recognition System")
self.geometry("1530x790+0+0")

#FIRST
img=Image.open(r"img\cs.jfif")
img=img.resize((500,130),Image.ANTIALIAS)
self.photoimg=ImageTk.PhotoImage(img)

F_lbl=Label(self,image=self.photoimg)
F_lbl.place(x=0,y=0,width=500,height=130)

#second
img1=Image.open(r"img\data.jfif")
img1=img1.resize((500,130),Image.ANTIALIAS)
self.photoimg1=ImageTk.PhotoImage(img1)

s_lbl=Label(self,image=self.photoimg1)
s_lbl.place(x=500,y=0,width=500,height=130)

#Thred
img2=Image.open(r"img\fac.jfif")
img2=img2.resize((550,130),Image.ANTIALIAS)
self.photoimg2=ImageTk.PhotoImage(img2)

t_lbl=Label(self,image=self.photoimg2)
t_lbl.place(x=1000,y=0,width=550,height=130)

#bg img
img3=Image.open(r"img\backgroud.jpg")
img3=img3.resize((1530,710),Image.ANTIALIAS)
self.photoimg3=ImageTk.PhotoImage(img3)

bg_img=Label(self,image=self.photoimg3)
bg_img.place(x=0,y=130,width=1530,height=710)

title_lbl=Label(bg_img,text="FACE RECOGNITION ATTENDANCE SYSTEM", font=("times new roman",35,"bold"),bg="white",fg="red")
title_lbl.place(x=0,y=0,width=1530,height=45)

#Student button
img4=Image.open(r"img\studentdetails.png")
img4=img4.resize((220,220),Image.ANTIALIAS)
self.photoimg4=ImageTk.PhotoImage(img4)

b1=Button(bg_img,image=self.photoimg4,cursor="hand2",command=root)
b1.place(x=200,y=100,width=220,height=220)

b1_1=Button(bg_img,text="Student Details",cursor="hand2",command=root,font=("times new roman",15,"bold"),bg="darkblue",fg="White")
b1_1.place(x=200,y=300,width=220,height=40)

#Detect face button
img5=Image.open(r"img\detection.png")
img5=img5.resize((220,220),Image.ANTIALIAS)
self.photoimg5=ImageTk.PhotoImage(img5)

b2=Button(bg_img,image=self.photoimg5,command=face_data,cursor="hand2")
b2.place(x=500,y=100,width=220,height=220)

b2_1=Button(bg_img,text="Face Detector",command=face_data,cursor="hand2",font=("times new roman",15,"bold"),bg="darkblue",fg="White")
b2_1.place(x=500,y=300,width=220,height=40)

#Attendance face button
img6=Image.open(r"img\techno.jfif")
img6=img6.resize((220,220),Image.ANTIALIAS)
self.photoimg6=ImageTk.PhotoImage(img6)

b3=Button(bg_img,image=self.photoimg6,command=Attendance,cursor="hand2")
b3.place(x=800,y=100,width=220,height=220)

b3_1=Button(bg_img,text="Attendance",command=Attendance,cursor="hand2",font=("times new roman",15,"bold"),bg="darkblue",fg="White")
b3_1.place(x=800,y=300,width=220,height=40)

#Help face button
img7=Image.open(r"img\help.png")
img7=img7.resize((220,220),Image.ANTIALIAS)
self.photoimg7=ImageTk.PhotoImage(img7)

b4=Button(bg_img,image=self.photoimg7,cursor="hand2",command=help)
b4.place(x=1100,y=100,width=220,height=220)

b4_1=Button(bg_img,text="Help Desk",command=help,cursor="hand2",font=("times new roman",15,"bold"),bg="darkblue",fg="White")
b4_1.place(x=1100,y=300,width=220,height=40)

#Train face button
img8=Image.open(r"img\datatrain.jpg")
img8=img8.resize((220,220),Image.ANTIALIAS)
self.photoimg8=ImageTk.PhotoImage(img8)

b5=Button(bg_img,image=self.photoimg8,command=train_data,cursor="hand2")
b5.place(x=200,y=380,width=220,height=220)

b5_1=Button(bg_img,text="Train Data",command=train_data,cursor="hand2",font=("times new roman",15,"bold"),bg="darkblue",fg="White")
b5_1.place(x=200,y=580,width=220,height=40)

#Photos face button
img9=Image.open(r"img\face.jfif")
img9=img9.resize((220,220),Image.ANTIALIAS)
self.photoimg9=ImageTk.PhotoImage(img9)

b6=Button(bg_img,image=self.photoimg9,cursor="hand2",command=open_img)
b6.place(x=500,y=380,width=220,height=220)

b6_1=Button(bg_img,text="Photos",command=open_img,cursor="hand2",font=("times new roman",15,"bold"),bg="darkblue",fg="White")
b6_1.place(x=500,y=580,width=220,height=40)

#Devloper face button
img10=Image.open(r"img\developer.jpg")
img10=img10.resize((220,220),Image.ANTIALIAS)
self.photoimg10=ImageTk.PhotoImage(img10)

b7=Button(bg_img,image=self.photoimg10,cursor="hand2",command=devloper)
b7.place(x=800,y=380,width=220,height=220)

b7_1=Button(bg_img,text="Devloper",command=devloper,cursor="hand2",font=("times new roman",15,"bold"),bg="darkblue",fg="White")
b7_1.place(x=800,y=580,width=220,height=40)

#Exit face button
img11=Image.open(r"img\exit.jfif")
img11=img11.resize((220,220),Image.ANTIALIAS)
self.photoimg11=ImageTk.PhotoImage(img11)

b8=Button(bg_img,image=self.photoimg11,cursor="hand2",command=iExit)
b8.place(x=1100,y=380,width=220,height=220)

b8_1=Button(bg_img,text="Exit",command=iExit,cursor="hand2",font=("times new roman",15,"bold"),bg="darkblue",fg="White")
b8_1.place(x=1100,y=580,width=220,height=40)

self.mainloop()
