from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk
from tkinter import messagebox
import mysql.connector

self=Tk()
self.title("Student Details")
self.geometry("1530x790+0+0")

title_lbl = Label(self, text="DEVELOPER", font=("times new roman", 35, "bold"), bg="white",fg="green")
title_lbl.place(x=0, y=0, width=1530, height=45)

img_top = Image.open(r"img\datatrain.jpg")
img_top = img_top.resize((1530,720), Image.ANTIALIAS)
self.photoimg_top = ImageTk.PhotoImage(img_top)

f_lbl = Label(self, image=self.photoimg_top)
f_lbl.place(x=0, y=55, width=1530, height=720)

main_frame = Frame(f_lbl, bd=2, bg="white")
main_frame.place(x=1000, y=0, width=500, height=600)

img_top1 = Image.open(r"img\developer.jpg")
img_top1 = img_top1.resize((200,200), Image.ANTIALIAS)
self.photoimg_top1 = ImageTk.PhotoImage(img_top1)

f_lbl = Label(main_frame, image=self.photoimg_top1)
f_lbl.place(x=300, y=0, width=200, height=200)

#dev info
dep_label=Label(main_frame,text="Hello my name is Irfan",font=("times new roman", 20, "bold"),bg="white")
dep_label.place(x=0,y=5)

dep_label=Label(main_frame,text="I am developer",font=("times new roman", 20, "bold"),bg="white")
dep_label.place(x=0,y=40)

img_top2 = Image.open(r"img\cs.jfif")
img_top2 = img_top2.resize((500,390), Image.ANTIALIAS)
self.photoimg_top2 = ImageTk.PhotoImage(img_top2)

f_lbl = Label(main_frame, image=self.photoimg_top2)
f_lbl.place(x=0, y=210, width=500, height=390)




















self.mainloop()
