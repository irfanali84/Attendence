from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
import mysql.connector
import cv2
from time import strftime
from datetime import datetime
import numpy as np
import os
import csv
from tkinter import filedialog



mydata=[]

self=Tk()
self.title("Face Recognition System")
self.geometry("1530x790+0+0")


#variable
self.atten_id=StringVar()
self.atten_roll=StringVar()
self.atten_name=StringVar()
self.atten_dep=StringVar()
self.atten_time=StringVar()
self.atten_date=StringVar()
self.atten_attendance=StringVar()



img_first = Image.open(r"img\cs.jfif")
img_first = img_first.resize((800,200), Image.ANTIALIAS)
self.photoimg_first = ImageTk.PhotoImage(img_first)

f_lbl = Label(self, image=self.photoimg_first)
f_lbl.place(x=0, y=0, width=800, height=200)

img_second = Image.open(r"img\fac.jfif")
img_second = img_second.resize((800,200), Image.ANTIALIAS)
self.photoimg_second = ImageTk.PhotoImage(img_second)

f_lbl = Label(self, image=self.photoimg_second)
f_lbl.place(x=800, y=0, width=800, height=200)


#bg img
img3=Image.open(r"img\backgroud.jpg")
img3=img3.resize((1530,710),Image.ANTIALIAS)
self.photoimg3=ImageTk.PhotoImage(img3)

bg_img=Label(self,image=self.photoimg3)
bg_img.place(x=0,y=130,width=1530,height=710)


title_lbl = Label(self, text="ATTENDANCE", font=("times new roman", 35, "bold"), bg="white",fg="green")
title_lbl.place(x=0, y=0, width=1530, height=45)

# frame
main_frame = Frame(bg_img, bd=2, bg="white")
main_frame.place(x=10, y=55, width=1500, height=600)

# left lbl frame
left_frame = LabelFrame(main_frame, bd=2, bg="white", relief=RIDGE, text="Student Attendance details",font=("times new roman", 12, "bold",))
left_frame.place(x=10, y=10, width=730, height=580)

img_left = Image.open(r"D:\pythonProject\Ai project\img\cs.jfif")
img_left = img_left.resize((550, 130), Image.ANTIALIAS)
self.photoimg_left = ImageTk.PhotoImage(img_left)

left_lbl = Label(left_frame, image=self.photoimg_left, bg="white")
left_lbl.place(x=5, y=0, width=720, height=130)

left_inside_frame = Frame(left_frame, bd=2,relief=RIDGE, bg="white")
left_inside_frame.place(x=0, y=135, width=720, height=370)

#Lab Entry
attendanceid_lbl = Label(left_inside_frame,text="AttendanceId:", font=("times new roman", 13, "bold",),bg="white")
attendanceid_lbl.grid(row=0, column=0, padx=10, pady=5, sticky=W)

attendanceid_entry = ttk.Entry(left_inside_frame,textvariable=self.atten_id, width=20, font=("times new roman", 13, "bold",))
attendanceid_entry.grid(row=0, column=1, padx=10, pady=5, sticky=W)

#Roll
roll_lbl = Label(left_inside_frame,text="Roll:", font=("times new roman", 13, "bold",),bg="white")
roll_lbl.grid(row=0, column=2, padx=10, pady=8, sticky=W)

roll_entry = ttk.Entry(left_inside_frame,textvariable=self.atten_roll, width=20, font=("times new roman", 13, "bold",))
roll_entry.grid(row=0, column=3, padx=10, pady=8, sticky=W)

#name
name_lbl = Label(left_inside_frame,text="Name:", font=("times new roman", 13, "bold",),bg="white")
name_lbl.grid(row=1, column=0, padx=10, pady=5, sticky=W)

name_entry = ttk.Entry(left_inside_frame,textvariable=self.atten_name, width=20, font=("times new roman", 13, "bold",))
name_entry.grid(row=1, column=1, padx=10, pady=8, sticky=W)

#department
dep_lbl = Label(left_inside_frame,text="Department:", font=("times new roman", 13, "bold",),bg="white")
dep_lbl.grid(row=1, column=2, padx=10, pady=8, sticky=W)

dep_entry = ttk.Entry(left_inside_frame, textvariable=self.atten_dep,width=20, font=("times new roman", 13, "bold",))
dep_entry.grid(row=1, column=3, padx=10, pady=8, sticky=W)

#time
time_lbl = Label(left_inside_frame,text="Time:", font=("times new roman", 13, "bold",),bg="white")
time_lbl.grid(row=2, column=0, padx=10, pady=8, sticky=W)

time_entry = ttk.Entry(left_inside_frame,textvariable=self.atten_time, width=20, font=("times new roman", 13, "bold",))
time_entry.grid(row=2, column=1, padx=10, pady=8, sticky=W)

#date
date_lbl = Label(left_inside_frame,text="Date:", font=("times new roman", 13, "bold",),bg="white")
date_lbl.grid(row=2, column=2, padx=10, pady=8, sticky=W)

date_entry = ttk.Entry(left_inside_frame,textvariable=self.atten_date, width=20, font=("times new roman", 13, "bold",))
date_entry.grid(row=2, column=3, padx=10, pady=8, sticky=W)

#ATTENDANCE
attendance_lbl = Label(left_inside_frame,text="Attendance Status:", font=("times new roman", 13, "bold",),bg="white")
attendance_lbl.grid(row=3, column=0, padx=10, pady=8, sticky=W)

self.atten_status = ttk.Combobox(left_inside_frame,textvariable=self.atten_attendance, width=20, font=("times new roman", 11, "bold",),state="readonly")
self.atten_status["value"]=("Status","Present","Absent")
self.atten_status.grid(row=3, column=1, padx=10, pady=8, sticky=W)
self.atten_status.current(0)

#fetch data
def fetch_data(rows):
    self.AttendaceReportTable.delete(*self.AttendaceReportTable.get_children())
    for i in rows:
        self.AttendaceReportTable.insert("",END,values=i)

#import csv
def import_csv():
    global mydata
    mydata.clear()
    fln=filedialog.askopenfilename(initialdir=os.getcwd(),title="Open CSV",filetypes=(("CSV File","*.csv"),("All File","*.*")),parent=self)
    with open(fln) as myfile:
        csvread=csv.reader(myfile,delimiter=",")
        for i in csvread:
            mydata.append(i)
        fetch_data(mydata)

#Export csv
def export_csv():
    try:
        if len(mydata)<1:
            messagebox.showerror("No Data","No Data found",parent=self)
            return False
        fln = filedialog.asksaveasfilename(initialdir=os.getcwd(), title="Open CSV",filetypes=(("CSV File", "*.csv"), ("All File", "*.*")), parent=self)
        with open(fln,mode="w",newline="") as myfile:
            exp_write=csv.writer(myfile,delimiter=",")
            for i in mydata:
                exp_write.writerow(i)
        messagebox.showinfo("Data export","Your data exported to"+os.path.basename(fln)+"successfully")
    except Exception as es:
        messagebox.showerror("Error",f"Due To :{str(es)}")


#show data
def get_cursor(event=""):
    cursor_row=self.AttendaceReportTable.focus()
    content=self.AttendaceReportTable.item(cursor_row)
    rows=content['values']
    self.atten_id.set(rows[0])
    self.atten_roll.set(rows[1])
    self.atten_name.set(rows[2])
    self.atten_dep.set(rows[3])
    self.atten_time.set(rows[4])
    self.atten_date.set(rows[5])
    self.atten_attendance.set(rows[6])


def reset_data():
    self.atten_id.set("")
    self.atten_roll.set("")
    self.atten_name.set("")
    self.atten_dep.set("")
    self.atten_time.set("")
    self.atten_date.set("")
    self.atten_attendance.set("")



#button frame
btn_frame = Frame(left_inside_frame, bd=2, relief=RIDGE, bg="white")
btn_frame.place(x=0, y=300, width=715, height=35)

# save
save_btn = Button(btn_frame, text="Import csv",command=import_csv, font=("times new roman", 13, "bold"), bg="blue", fg="white", width=17,cursor="hand2")
save_btn.grid(row=0, column=0, sticky=W)

# update
update_btn = Button(btn_frame, text="Export csv",command=export_csv, font=("times new roman", 13, "bold"), bg="blue", fg="white",width=17,cursor="hand2")

update_btn.grid(row=0, column=1, sticky=W)


#reset
reset_btn = Button(btn_frame, text="Reset",command=reset_data, font=("times new roman", 13, "bold"), bg="blue", fg="white", width=17,cursor="hand2")
reset_btn.grid(row=0, column=3, sticky=W)


# right lbl frame
right_frame = LabelFrame(main_frame, bd=2, bg="white", relief=RIDGE, text="Attendance details",font=("times new roman", 12, "bold",))
right_frame.place(x=750, y=10, width=730, height=580)

table_frame = Frame(right_frame, bd=2, relief=RIDGE, bg="white")
table_frame.place(x=5, y=5, width=700, height=445)

#scrollbar

scroll_x=ttk.Scrollbar(table_frame,orient=HORIZONTAL)
scroll_y=ttk.Scrollbar(table_frame,orient=VERTICAL)

self.AttendaceReportTable=ttk.Treeview(table_frame,column=("id","roll","name","department","time","date","attendance",),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
scroll_x.pack(side=BOTTOM,fill=X)
scroll_y.pack(side=RIGHT,fill=Y)

scroll_x.config(command=self.AttendaceReportTable.xview)
scroll_y.config(command=self.AttendaceReportTable.yview)

self.AttendaceReportTable.heading("id",text="Attendance ID")
self.AttendaceReportTable.heading("roll",text="Roll")
self.AttendaceReportTable.heading("name",text="Name")
self.AttendaceReportTable.heading("department",text="Department")
self.AttendaceReportTable.heading("time",text="Time")
self.AttendaceReportTable.heading("date",text="Date")
self.AttendaceReportTable.heading("attendance",text="Attendance")

self.AttendaceReportTable["show"]="headings"

self.AttendaceReportTable.column("id",width=100)
self.AttendaceReportTable.column("roll",width=100)
self.AttendaceReportTable.column("name",width=100)
self.AttendaceReportTable.column("department",width=100)
self.AttendaceReportTable.column("time",width=100)
self.AttendaceReportTable.column("date",width=100)
self.AttendaceReportTable.column("attendance",width=100)




self.AttendaceReportTable.pack(fill=BOTH,expand=1)
self.AttendaceReportTable.bind("<ButtonRelease>",get_cursor)
















self.mainloop()